GM.Name 		= "EXPLOSIVES"
GM.Author 		= "TheBoigamer11"
GM.Email 		= ""
GM.Website 		= ""

hook.Add( "PlayerNoClip", "FeelFreeToTurnItOff", function( ply, desiredState )
	return false
end )