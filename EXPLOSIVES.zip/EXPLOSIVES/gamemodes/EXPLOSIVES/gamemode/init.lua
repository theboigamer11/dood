AddCSLuaFile( "cl_init.lua" )
AddCSLuaFile( "shared.lua" )

include( "shared.lua" )

CreateConVar( "zombie_surival", 0, 0, "turns the gamemode from deathmatch to zombie survival", 0, 1 )
convar = GetConVar( "zombie_surival" )

playermodels = {
	"models/player/skeleton.mdl",
	"models/player/gman_high.mdl",
	"models/player/kleiner.mdl",
	"models/player/Group01/male_07.mdl",
	"models/player/combine_soldier.mdl",
	"models/player/monk.mdl",
	"models/player/Group01/female_02.mdl",
	"models/player/eli.mdl"
}

function GM:PlayerSpawn(ply)
	ply:SetupHands()
	ply:SetMaxHealth(200)
	ply:SetMaxSpeed( 300 )
	ply:SetModel( playermodels[ math.random( #playermodels ) ] )
	ply:Give("weapon_crowbar")
	ply:Give("weapon_physcannon")
	ply:Give("weapon_pistol")
	ply:Give("weapon_smg1")
	ply:Give("weapon_shotgun")
	ply:Give("weapon_frag")
	ply:Give("weapon_357")
end

-- Define the explosion function
local function Explode(pos)
    local explosion = ents.Create("env_explosion")
    explosion:SetPos(pos)
    explosion:SetKeyValue("iMagnitude", "60")
    explosion:Spawn()
    explosion:Fire("Explode", 0, 0)
end

-- Define the bullet impact function
local function BulletImpact(attacker, trace)
    Explode(trace.HitPos) -- Spawn an explosion at the impact position
end

-- Hook into the bullet impact event
hook.Add("EntityFireBullets", "BulletImpactExplosion", function(ent, data)
    local attacker = data.Attacker
    local pos = data.Src
    local dir = data.Dir
    local range = data.Distance
    local filter = function(ent) 
        if ent == attacker then return false end -- Exclude the bullet's attacker from the trace
        if ent:IsPlayer() or ent:IsNPC() then return true end -- Trace through players and NPCs
        return false
    end
    local trace = util.TraceLine({
        start = pos,
        endpos = pos + dir * range,
        filter = filter
    })
    BulletImpact(attacker, trace) -- Call the bullet impact function
end)

function GM:Move( ply, mv )
	if ply:KeyDown(IN_JUMP) then
	   if ply:OnGround() then
			if ply:GetVelocity():Length() < 750 then
				if ( !ply:KeyDown( IN_FORWARD ) and !ply:KeyDown( IN_BACK) ) then
					ply:SetVelocity(ply:GetVelocity() + Vector(0, 0, 1))
				end
			end
	   end
	end
end

local t = 0

hook.Add("Think", "tick",function()
	if convar:GetBool() == true then
		if t < CurTime() then
			t = CurTime() + 2
			
			local spawns = ents.FindByClass("info_player_start")
			if #spawns < 2 then
				spawns = ents.FindByClass("info_player_deathmatch")
				if #spawns < 1 then
					spawns = ents.FindByClass("info_player_start")
				end
			end
			local random_entry = math.random(#spawns)
			local Ent = ents.Create("npc_zombie")
			
			Ent:SetPos( spawns[random_entry]:GetPos() + Vector(0,0,5))
			Ent:Spawn()
		end
	end
end)